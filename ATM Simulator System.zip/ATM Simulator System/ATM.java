import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ATM {
    private Connection connection;
    private User currentUser;

    public ATM() {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            System.err.println("Failed to connect to database: " + e.getMessage());
        }
    }

    public boolean login(String username, String pin) {
        String query = "SELECT * FROM users WHERE username = ? AND pin = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, pin);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                currentUser = new User(
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("pin"),
                    rs.getDouble("balance")
                );
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Login error: " + e.getMessage());
        }
        return false;
    }

    public double checkBalance() {
        if (currentUser != null) {
            return currentUser.getBalance();
        }
        return -1;
    }

    public boolean deposit(double amount) {
        if (currentUser == null || amount <= 0) return false;

        String updateBalance = "UPDATE users SET balance = balance + ? WHERE user_id = ?";
        String insertTransaction = "INSERT INTO transactions (user_id, type, amount, balance_after) VALUES (?, ?, ?, ?)";

        try {
            connection.setAutoCommit(false);
            
            // Update balance
            try (PreparedStatement stmt = connection.prepareStatement(updateBalance)) {
                stmt.setDouble(1, amount);
                stmt.setInt(2, currentUser.getUserId());
                stmt.executeUpdate();
            }

            // Get updated balance
            double newBalance = currentUser.getBalance() + amount;
            currentUser.setBalance(newBalance);

            // Record transaction
            try (PreparedStatement stmt = connection.prepareStatement(insertTransaction)) {
                stmt.setInt(1, currentUser.getUserId());
                stmt.setString(2, "DEPOSIT");
                stmt.setDouble(3, amount);
                stmt.setDouble(4, newBalance);
                stmt.executeUpdate();
            }

            connection.commit();
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                System.err.println("Rollback failed: " + ex.getMessage());
            }
            System.err.println("Deposit error: " + e.getMessage());
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                System.err.println("Error resetting auto-commit: " + e.getMessage());
            }
        }
    }

    public boolean withdraw(double amount) {
        if (currentUser == null || amount <= 0 || amount > currentUser.getBalance()) return false;

        String updateBalance = "UPDATE users SET balance = balance - ? WHERE user_id = ?";
        String insertTransaction = "INSERT INTO transactions (user_id, type, amount, balance_after) VALUES (?, ?, ?, ?)";

        try {
            connection.setAutoCommit(false);
            
            // Update balance
            try (PreparedStatement stmt = connection.prepareStatement(updateBalance)) {
                stmt.setDouble(1, amount);
                stmt.setInt(2, currentUser.getUserId());
                stmt.executeUpdate();
            }

            // Get updated balance
            double newBalance = currentUser.getBalance() - amount;
            currentUser.setBalance(newBalance);

            // Record transaction
            try (PreparedStatement stmt = connection.prepareStatement(insertTransaction)) {
                stmt.setInt(1, currentUser.getUserId());
                stmt.setString(2, "WITHDRAWAL");
                stmt.setDouble(3, amount);
                stmt.setDouble(4, newBalance);
                stmt.executeUpdate();
            }

            connection.commit();
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                System.err.println("Rollback failed: " + ex.getMessage());
            }
            System.err.println("Withdrawal error: " + e.getMessage());
            return false;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                System.err.println("Error resetting auto-commit: " + e.getMessage());
            }
        }
    }

    public List<Transaction> getTransactionHistory() {
        if (currentUser == null) return new ArrayList<>();

        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE user_id = ? ORDER BY timestamp DESC LIMIT 10";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, currentUser.getUserId());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction(
                    rs.getInt("transaction_id"),
                    rs.getInt("user_id"),
                    rs.getString("type"),
                    rs.getDouble("amount"),
                    rs.getDouble("balance_after"),
                    rs.getTimestamp("timestamp")
                );
                transactions.add(transaction);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching transaction history: " + e.getMessage());
        }
        return transactions;
    }

    public void logout() {
        currentUser = null;
    }

    public void closeATM() {
        DatabaseConnection.closeConnection(connection);
    }
}