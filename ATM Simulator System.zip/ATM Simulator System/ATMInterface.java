import java.util.List;
import java.util.Scanner;

public class ATMInterface {
    private static ATM atm;
    private static Scanner scanner;

    public static void main(String[] args) {
        atm = new ATM();
        scanner = new Scanner(System.in);

        while (true) {
            if (!showLoginMenu()) break;
            showMainMenu();
        }

        scanner.close();
        atm.closeATM();
        System.out.println("Thank you for using our ATM. Goodbye!");
    }

    private static boolean showLoginMenu() {
        System.out.println("\n=== Welcome to the ATM System ===");
        System.out.println("1. Login");
        System.out.println("2. Exit");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (choice == 2) return false;

        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter PIN: ");
        String pin = scanner.nextLine();

        if (atm.login(username, pin)) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Invalid username or PIN!");
            return true;
        }
    }

    private static void showMainMenu() {
        boolean running = true;
        while (running) {
            System.out.println("\n=== ATM Main Menu ===");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transaction History");
            System.out.println("5. Logout");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    checkBalance();
                    break;
                case 2:
                    deposit();
                    break;
                case 3:
                    withdraw();
                    break;
                case 4:
                    showTransactionHistory();
                    break;
                case 5:
                    atm.logout();
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option!");
            }
        }
    }

    private static void checkBalance() {
        double balance = atm.checkBalance();
        if (balance >= 0) {
            System.out.printf("Your current balance is: $%.2f%n", balance);
        } else {
            System.out.println("Error checking balance!");
        }
    }

    private static void deposit() {
        System.out.print("Enter amount to deposit: $");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        if (amount <= 0) {
            System.out.println("Invalid amount!");
            return;
        }

        if (atm.deposit(amount)) {
            System.out.println("Deposit successful!");
            checkBalance();
        } else {
            System.out.println("Deposit failed!");
        }
    }

    private static void withdraw() {
        System.out.print("Enter amount to withdraw: $");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        if (amount <= 0) {
            System.out.println("Invalid amount!");
            return;
        }

        if (atm.withdraw(amount)) {
            System.out.println("Withdrawal successful!");
            checkBalance();
        } else {
            System.out.println("Withdrawal failed! Please check your balance.");
        }
    }

    private static void showTransactionHistory() {
        List<Transaction> transactions = atm.getTransactionHistory();
        if (transactions.isEmpty()) {
            System.out.println("No transactions found!");
            return;
        }

        System.out.println("\n=== Transaction History ===");
        for (Transaction transaction : transactions) {
            System.out.println(transaction);
        }
    }
}