-- Create the database
CREATE DATABASE IF NOT EXISTS atm_db;
USE atm_db;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    pin VARCHAR(4) NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    type VARCHAR(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    balance_after DECIMAL(10,2) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Insert sample users
INSERT INTO users (username, pin, balance) VALUES
('john_doe', '1234', 1000.00),
('jane_smith', '5678', 2500.00);

-- Insert sample transactions
INSERT INTO transactions (user_id, type, amount, balance_after) VALUES
(1, 'DEPOSIT', 500.00, 500.00),
(1, 'DEPOSIT', 500.00, 1000.00),
(2, 'DEPOSIT', 3000.00, 3000.00),
(2, 'WITHDRAWAL', 500.00, 2500.00);

-- Create indexes for better performance
CREATE INDEX idx_username ON users(username);
CREATE INDEX idx_user_transactions ON transactions(user_id, timestamp);